package com.example.tastyapi


data class info(
    val name: String,
    val thumbnail_url: String,
    val createdAt: String
)
